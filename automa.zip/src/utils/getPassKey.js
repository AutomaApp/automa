/*eslint-disable*/
export default function(a, b) {
  let output = '';
  const chars = [18, 35, -5, 47, -4, 45, -18, 20, -21, 48, -1, 42, 36, 41, 34, -6];

  chars.forEach((char) => {
    output += String.fromCharCode(char + 69);
  });

  return output;
};